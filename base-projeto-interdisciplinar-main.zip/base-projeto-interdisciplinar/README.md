# Projeto-Interdisciplinar
Projeto interdisciplinar entre as disciplinas 
    
  - Bando de dados 3 (BD3), 
  - Programação e Tecnologias aplicadas a clientes 3 (PTAC 3)
  - Programação e Tecnologias aplicadas a Servidor 2 (PTAS 2)
